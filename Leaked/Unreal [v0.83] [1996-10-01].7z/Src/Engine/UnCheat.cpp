/*==============================================================================
UnCheat.cpp: Unreal cheats

Copyright 1996 Epic MegaGames, Inc. This software is a trade secret.
Compiled with Visual C++ 4.0, Calling method=__fastcall

Description:
    Refer to the associated header file.

Revision history:
    * 08/11/96: Created by Mark
==============================================================================*/

#include "UnCheat.h"

UNREAL_API FCheat * GCheat;

