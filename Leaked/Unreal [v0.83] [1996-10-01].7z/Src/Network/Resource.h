//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Network.rc
//
#define IDS_DESCRIPTION                 1
#define IDC_EDIT_OPTIONS                3
#define IDD_FAKEWIZARD                  101
#define ID_SUCCESS                      101
#define IDB_NETWIZ                      111
#define IDR_MAINFRAME                   112
#define IDD_INETOPEN                    149
#define IDD_DPLAYPROVIDER               150
#define IDD_DPLAYPROVIDERS              150
#define IDD_DPLAYSESSIONS               151
#define IDD_STARTSERVER                 152
#define IDD_NETWIZ                      153
#define IDD_JOINTYPE                    154
#define IDD_HOSTTYPE                    155
#define IDD_INETPROVIDER                156
#define IDD_SERVERPROP                  157
#define IDC_LEVEL_SINGLE                1000
#define IDC_LEVEL_MULTI                 1001
#define IDC_LEVEL                       1002
#define IDC_LEVEL_FIND                  1003
#define ID_BACK                         1005
#define IDC_JOIN                        1006
#define ID_CONFIGURE                    1006
#define IDC_HOST                        1007
#define IDC_DPLAY                       1008
#define IDC_DIRECTORY                   1010
#define IDC_PROGRESS                    1011
#define IDC_EPICSERVER                  1011
#define IDC_NAME                        1012
#define IDC_PLAYERNAME                  1013
#define ID_NEXT                         1013
#define IDD_LAUNCH                      1013
#define IDC_PSWD                        1013
#define IDC_PASSWORD                    1014
#define ID_CONNECT                      1014
#define IDC_SERVERNAME                  1015
#define IDC_INET                        1015
#define IDC_PROVIDERS                   1016
#define IDC_DEST                        1016
#define IDC_LIST1                       1017
#define IDC_SESSIONS                    1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
