/*=============================================================================
	StdAfx.cpp: Standard MFC includes
	Used by: Log window

	Copyright 1997 Epic MegaGames, Inc. This software is a trade secret.
	Compiled with Visual C++ 4.0. Best viewed with Tabs=4.

	Revision history:
		* Created by Tim Sweeney
=============================================================================*/

#include "StdAfx.h"

/*-----------------------------------------------------------------------------
	The End.
-----------------------------------------------------------------------------*/
