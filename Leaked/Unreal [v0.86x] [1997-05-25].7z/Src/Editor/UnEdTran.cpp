/*=============================================================================
	UnEdTran.cpp: Unreal transaction-tracking functions

	Copyright 1997 Epic MegaGames, Inc. This software is a trade secret.
	Compiled with Visual C++ 4.0. Best viewed with Tabs=4.

	The functions here are used for tracking modifications to the Bsp, editor
	solids, actors, etc., to support "Undo", "Redo", and automatically aborting
	operations which cause problems (while undoing their changes).

	See end of file for more information about all things tracked.

	Revision history:
		* Created by Tim Sweeney
=============================================================================*/

#include "Unreal.h"

/*-----------------------------------------------------------------------------
	All transaction-related data types.
-----------------------------------------------------------------------------*/

class FTransaction			// Transaction (one entry per transaction).
{
public:
	int	TransCount;			// Transaction number, starts at 0 when loaded and counts up.
	int	StartDataOffset;	// Data offset where transaction data starts.
	int	TotalDataSize;		// Total size of all data for the transaction.
	int	NumChanges;			// Number of changes thus far.
	char Name[80];			// Description of transaction.
};

class FTransChangeLog  		// Log of additions/deletions/modifications to records.
{
public:
	UObject		*Res;		// Object operated on.
	int			Index;		// Index of element.
	int			TransCount;	// Transaction number the change corresponds to.
	int			DataOffset;	// Offset of data in data buffer.
	int			DataSize;	// Size of this change's data in data buffer.
};

/*-----------------------------------------------------------------------------
	UTransBuffer constructor.
-----------------------------------------------------------------------------*/

UTransBuffer::UTransBuffer
(
	int ThisMaxTrans,
	int ThisMaxChanges,
	int ThisMaxDataOffset
)
{
	// Set values.
	MaxTrans		= ThisMaxTrans;
	MaxChanges		= ThisMaxChanges;
	MaxDataOffset	= ThisMaxDataOffset;

	// Allocate it.
	Realloc();

	// Subsystem init message.
	debug (LOG_Init,"Transaction tracking system initialized");
}

/*-----------------------------------------------------------------------------
	Lock, Unlock, and Reset.
-----------------------------------------------------------------------------*/

//
// Lock the transaction tracking object.
//
INT UTransBuffer::Lock(DWORD NewLockType)
{
	guard(UTransBuffer::Lock);
	checkInput(NewLockType!=LOCK_None);
	checkState(!IsLocked());
	
	DWORD	TransactionSize	= MaxTrans 		* sizeof (FTransaction);
	DWORD	ChangeLogSize	= MaxChanges	* sizeof (FTransChangeLog);
	DWORD	DataSize		= MaxDataOffset;

	if( !GApp->ServerAlive )
		return 1;

	Transactions 	= (FTransaction		*)((BYTE *)GetData() + 0);
	ChangeLog 		= (FTransChangeLog  *)((BYTE *)GetData() + TransactionSize);
	Buffer 			= (BYTE				*)((BYTE *)GetData() + TransactionSize + ChangeLogSize);

	return UObject::Lock(NewLockType);
	unguard;
}

//
// Unlock transaction buffer.
//
void UTransBuffer::Unlock(DWORD OldLockType)
{
	guard(UTransBuffer::Unlock);
	checkState( IsLocked() );
	
	if( !GApp->ServerAlive )
		return;

	UObject::Unlock(OldLockType);
	unguard;
}

//
// Reset the transaction tracking system, clearing all transactions (so that
// following undo/redo operations can't occur).  This is called before a
// routine that invalidates the main set of level/transaction data, for example
// before rebuilding the Bsp.
//
// Action = description of reason for reset (i.e. "loading level", "rebuilding Bsp")
//
void UTransBuffer::Reset( const char *Action )
{
	guard(UTransBuffer::Reset);
	if( !GApp->ServerAlive )
		return;
	
	strcpy (ResetAction,Action);
	NumTrans		= 0;
	NumChanges		= 0;
	Overflow 		= 0;
	TransCount		= 0;
	UndoTransCount	= 0;

	debugf(LOG_Info,"Transaction buffer %s reset",GetName());
	unguard;
}

/*-----------------------------------------------------------------------------
	Deletion.
-----------------------------------------------------------------------------*/

//
// Delete the first transaction from the transaction list, remove all of its entries
// from the change log and data tables, and scroll the list down.
//
void UTransBuffer::DeleteFirstTransaction()
{
	guard(UTransBuffer::DeleteFirstTransaction);

	FTransaction 	*FirstTrans,*LastTrans;
	int				MinTransCount;
	int				MinDataOffset,MaxDataOffset;
	int 			i,j;

	if( !GApp->ServerAlive )
		return;
	
	checkState(IsLocked());
	checkState(NumTrans!=0);	

	// Remove from *Transactions.
	for( i=1; i<NumTrans; i++ )
		Transactions[i-1] = Transactions[i];
	
	NumTrans--;

	if( NumTrans == 0 )
	{
		// All transactions are gone, so just empty everything.
		NumChanges = 0;
	}
	else
	{
		FirstTrans = &Transactions [0];
		LastTrans  = &Transactions [NumTrans-1];

		MinTransCount = FirstTrans->TransCount;

		MinDataOffset = FirstTrans->StartDataOffset;
		MaxDataOffset = LastTrans ->StartDataOffset + LastTrans->TotalDataSize;

		// Move data and update data offsets for all remaining transactions.
		memmove (Buffer, Buffer + MinDataOffset, MaxDataOffset-MinDataOffset);
		for( i=0; i<NumTrans; i++ )
			Transactions[i].StartDataOffset -= MinDataOffset;

		// Delete all old entries from TRANS.ChangeLog.
		j=0;
		for( i=0; i<NumChanges; i++ )
		{
			if( ChangeLog[i].TransCount >= MinTransCount )
			{
				if( j != i )
					ChangeLog[j] = ChangeLog[i];
				j++;
			}
			else
			{
				// The entry has been passed over (deleted).
			}
		}
		NumChanges = j;
	}
	unguard;
}

/*-----------------------------------------------------------------------------
	Begin, End, Rollback, Continue.
-----------------------------------------------------------------------------*/

//
// Begin a new transaction.  If any undone transactions haven't been redone,
// they will be overwritten.
//
void UTransBuffer::Begin( ULevel *Level, const char *SessionName )
{
	guard(UTransBuffer::Begin);

	FTransaction	*Transaction;
	int				Index,Count;

	// Check existing transaction status.
	if (!GApp->ServerAlive) return;
	checkState(!IsLocked());
	debugf(LOG_Info,"Begin transaction %s",SessionName);

	Lock(LOCK_ReadWrite);
	Overflow = 0;

	//
	// If transaction list is full, must scroll it back by deleting first entry.
	if (NumTrans >= MaxTrans) DeleteFirstTransaction();

	// If undo without matching redo's, cut off the rest of the list.
	Count = 0;
	for( int i=0; i<NumTrans; i++ )
	{
		if( Transactions[i].TransCount >= UndoTransCount )
		{
			NumTrans    = i;
			TransCount  = UndoTransCount;
			break;
		}
		else
		{
			Count += Transactions[i].NumChanges;
		}
	}
	NumChanges = Count;

	// Fill in *Transaction information.
	Index                	= NumTrans++;
	Transaction				= &Transactions[Index];
	Transaction->TransCount	= TransCount++;
	Transaction->NumChanges = 0;

	// Will be increased as changes are logged.
	strcpy (Transaction->Name,SessionName);
	Transaction->TotalDataSize = 0;

	// Set undo pointer to very top of transaction list.
	UndoTransCount    = TransCount;

	// Calc starting data offset.
	if( NumTrans==1 )
	{
		Transaction->StartDataOffset = 0;
	}
	else
	{
		Transaction->StartDataOffset =
		Transactions [Index-1].StartDataOffset +
		Transactions [Index-1].TotalDataSize;
	}
	unguard;
}

//
// End a transaction
//
void UTransBuffer::End()
{
	guard(UTransBuffer::End);
	if( !GApp->ServerAlive )
		return;

	checkState(IsLocked());

	Unlock(LOCK_ReadWrite);
	if( Overflow )
	{
		debugf(LOG_Info,"End overflowed transaction");
		Reset("Undo buffer filled up");
	}
	else
	{
		//debugf (LOG_Trans,"End transaction");
	}
	unguard;
}

void UTransBuffer::ForceOverflow( const char *Reason )
{
	guard(UTransBuffer::ForceOverflow);
	if (!GApp->ServerAlive) return;
	Overflow = 1;
	unguard;
}

//
// Abort a transaction and restore original state
//
void UTransBuffer::Rollback( ULevel *Level )
{
	guard(UTransBuffer::Rollback);
	checkState(IsLocked());

	if( !GApp->ServerAlive )
		return;
	
	if( Overflow )
	{
		// Can't rollback overflowed transactions because data is gone.
		End();
	}
	else
	{
		End();
		Undo(Level);

		// Prevent rolled-back transaction from being redone.
		if (NumTrans>0)		NumTrans--;
		if (TransCount>0)	TransCount--;

		UndoTransCount = TransCount;

		// Wipe out the rolled-back transaction's changes.
		NumChanges = 0;
		for( int i=0; i<NumTrans; i++ )
			NumChanges += Transactions[i].NumChanges;
	}
	unguard;
}

//
// Reopen the previous transaction and continue it
//
void UTransBuffer::Continue()
{
	guard(UTransBuffer::Continue);
	checkState(!IsLocked());

	if( !GApp->ServerAlive )
		return;
	
	debugf(LOG_Info,"Continue previous transaction");

	Lock(LOCK_ReadWrite);
	if (NumTrans==0)	Overflow    = 1; // Assume previous transaction overflowed
	else				Overflow 	= 0;
	unguard;
}

/*-----------------------------------------------------------------------------
	Applying Undo/Redo changes.
-----------------------------------------------------------------------------*/

//
// Swap memory in one buffer with another
//
void memswap( void *Ptr1, void *Ptr2, DWORD Size )
{
	guard(memswap);

	FMemMark Mark(GMem);
	BYTE *Temp = new(GMem,Size)BYTE;
	memcpy (Temp,Ptr1,Size);
	memcpy (Ptr1,Ptr2,Size);
	memcpy (Ptr2,Temp,Size);
	Mark.Pop();

	unguard;
}

//
// Begin applying changes.
//
void UTransBuffer::BeginChanges( FTransaction *Trans )
{
	guard(UTransBuffer::BeginChanges);

	// Tag all objects as "not affected by transaction tracking system".
	UObject *Res;
	FOR_ALL_OBJECTS(Res)
	{
		Res->ClearFlags( RF_TransHeader | RF_TransData );
	}
	END_FOR_ALL_OBJECTS;
	unguard;
}

//
// End applying changes and do any necessary cleanup work.
//
void UTransBuffer::EndChanges( FTransaction *Trans )
{
	guard(UTransBuffer::EndChanges);

	// Postload all objects.
	UObject *Res;
	FOR_ALL_OBJECTS(Res)
	{
		if( Res->GetFlags() & RF_TransHeader )
		{
			// Call object postloader.
			Res->PostLoadHeader( POSTLOAD_Trans );
			Res->ClearFlags( RF_TransHeader );
		}
	}
	END_FOR_ALL_OBJECTS;
	unguard;
}

//
// Apply one logged change, Undo = 1 (Undo), 0 (Redo).
//
void UTransBuffer::ApplyChange( FTransChangeLog *Change, BYTE *SourcePtr, DWORD DataSize )
{
	guard(UTransBuffer::ApplyChange);

	if( Change->Index >= 0 )
	{
		UDatabase	*Res   	= (UDatabase *)Change->Res;
		UClass      *Class 	= Res->GetClass();
		BYTE		*DestPtr;
		checkLogic(DataSize==Class->ResRecordSize);
		//debugf("Applying %s.%s %i",Res->GetClassName(),Res->GetName(),Change->Index);

		// Lock the object.
		Change->Res->Lock(LOCK_ReadWrite);

		// Change a data record.
		DestPtr = ((BYTE *)Change->Res->GetData()) + Change->Index * Class->ResRecordSize;

		// Mark it.
		Res->SetFlags(RF_TransData);

		// Swap the memory.
		memswap( DestPtr, SourcePtr, DataSize );
		Change->Res->InitLocks();

		// PostLoad it.
		Change->Res->Lock(LOCK_ReadWrite);
		Res->PostLoadItem( Change->Index, POSTLOAD_Trans );
		Change->Res->Unlock(LOCK_ReadWrite);

		// Unlock it.
	}
	else
	{
		// Change object header.
		UObject *Dest   = (UDatabase *)Change->Res;
		UObject *Source	= (UDatabase *)SourcePtr;
		checkState(DataSize == Dest->GetClass()->ResFullHeaderSize);
		//debugf("Applying %s.%s",Dest->GetClassName(),Dest->GetName());

		// Remember that we have performed a transaction on this object.
		DWORD DestFlags = RF_TransHeader | (Dest->GetFlags() & RF_TransData);

		void *CurrentData=NULL;
		int CurrentMax=0, NewMax;
		if( Dest->GetClass()->ResRecordSize != 0 )
		{
			// Remember database's current data pointer.
			Dest->InitLocks();
			Dest->Lock(LOCK_ReadWrite);
			CurrentData	= Dest->GetData();
			CurrentMax  = ((UDatabase *)Dest  )->Max;
			NewMax      = ((UDatabase *)Source)->Max;

			// Reallocate data if max increased.
			if( NewMax > CurrentMax )
			{
				CurrentData = appRealloc
				(
					CurrentData,
					NewMax * Dest->GetClass()->ResRecordSize,
					"Trans"
				);
				CurrentMax = NewMax;
			}
		}

		// Swap the header.
		memswap(Dest,Source,DataSize);

		if( Dest->GetClass()->ResRecordSize != 0 )
		{
			// Update the data pointer and max.
			Dest->SetData(CurrentData);
			((UDatabase *)Dest)->Max = CurrentMax;
		}

		// Mark the thing as unlocked.
		Dest->InitLocks();
		Dest->SetFlags(DestFlags);
	}
	unguard;
}

/*-----------------------------------------------------------------------------
	Undo.
-----------------------------------------------------------------------------*/

//
// Returns 1 if "undo" is possible, sets Str to name.
//
int UTransBuffer::CanUndo( char *Str )
{
	guard(UTransBuffer::CanUndo);

	if( !GApp->ServerAlive )
		return 0;
	
	Lock(LOCK_ReadWrite);

	if( (NumTrans==0) ||
		(UndoTransCount <= Transactions[0].TransCount) )
	{
		strcpy (Str,ResetAction);
		Unlock(LOCK_ReadWrite);
		return 0;
	}

	// Find transaction name.
	for( int i=0; i < NumTrans; i++ )
	{
		if( Transactions[i].TransCount == (UndoTransCount-1) )
		{
			strcpy (Str,Transactions[i].Name);
			Unlock(LOCK_ReadWrite);
			return 1;
		}
	}
	strcpy(Str,"aborted transaction");
	Unlock(LOCK_ReadWrite);
	return 1;
	unguard;
}

//
// Undo a transaction, 1 if undone, 0 if not possible.
//
int UTransBuffer::Undo( ULevel *Level )
{
	guard(UTransBuffer::Undo);

	FTransaction	*Transaction;
	FTransChangeLog	*Change;
	char			Descr[256];
	int 			i;

	if( !GApp->ServerAlive )
		return 0;

	// See if undo is possible.
	if( !CanUndo(Descr) )
	{
		if( UndoTransCount == 0 )
		{
			// At beginning of transaction list.
			debugf(LOG_Info,"Can't undo after %s",Descr);
		}
		else
		{
			debugf(LOG_Info,"At end of undo buffer");
		}
		return 0;
	}
	// Print name of what we're undoing.
	debugf(LOG_Info,"Undo %s",Descr);

	Lock(LOCK_ReadWrite);
	UndoTransCount--;

	// Find transaction corresponding to UndoTransCount.
	Transaction = &Transactions[0];
	for( i=0; i<NumTrans; i++ )
	{
		if (Transaction->TransCount == UndoTransCount) goto Found;
		Transaction++;
	}
	debugf(LOG_Info,"Not found");
	Unlock(LOCK_ReadWrite);
	return 0;

	// Apply all "undo" changes corresponding to UndoTransCount, in reverse order.
	Found:
	BeginChanges(Transaction);
	for( i=NumChanges-1; i >= 0; i-- )
	{
		Change = &ChangeLog[i];
		if( Change->TransCount == UndoTransCount )
		{
			ApplyChange
			(
				Change,
				Buffer + Transaction->StartDataOffset + Change->DataOffset,
				Change->DataSize
			);
		}
	}
	EndChanges( Transaction );
	Unlock(LOCK_ReadWrite);
	return 1;
	unguard;
}

/*-----------------------------------------------------------------------------
	Redo.
-----------------------------------------------------------------------------*/

//
// Returns 1 if "redo" is possible, sets Str to name.
//
int UTransBuffer::CanRedo( char *Str )
{
	guard(UTransBuffer::CanRedo);

	FTransaction	*Transaction;
	int 			i;

	if( !GApp->ServerAlive )
		return 0;
	
	Lock(LOCK_ReadWrite);

	if( (NumTrans==0) || (UndoTransCount >= TransCount) )
	{
		strcpy (Str,"");
		Unlock(LOCK_ReadWrite);
		return 0;
	}

	// Find transaction name.
	Transaction = &Transactions[0];
	for( i=0; i<NumTrans; i++ )
	{
		if( Transaction->TransCount ==  UndoTransCount )
		{
			strcpy (Str,Transaction->Name);
			Unlock(LOCK_ReadWrite);
			return 1;
		}
		Transaction++;
	}
	strcpy(Str,"aborted transaction");
	Unlock(LOCK_ReadWrite);
	return 1;
	unguard;
}

//
// Redo a transaction, 1 if undone, 0 if not possible.
//
int UTransBuffer::Redo( ULevel *Level )
{
	guard(UTransBuffer::Redo);

	FTransaction	*Transaction;
	FTransChangeLog	*Change;
	char			Descr[256];
	int 			i;

	if( !GApp->ServerAlive )
		return 0;

	// See if redo is possible.
	if( !CanRedo(Descr) )
	{
		debugf(LOG_Info,"Nothing to redo",Descr);
		return 0; // Can't redo
	}
	
	// Print name of what we're undoing.
	debugf(LOG_Info,"Redo %s",Descr);

	// Find transaction corresponding to UndoTransCount.
	Lock(LOCK_ReadWrite);

	Transaction = &Transactions [0];
	for( i=0; i<NumTrans; i++ )
	{
		if (Transaction->TransCount == UndoTransCount) goto Found;
		Transaction++;
	}
	debugf(LOG_Info,"Not found");
	UndoTransCount++;
	Unlock(LOCK_ReadWrite);
	return 0;

	// Apply all "redo" changes corresponding to TRANS.UndoTransCount.
	Found:

	BeginChanges (Transaction);
	for( i=0; i<NumChanges; i++ )
	{
		Change = &ChangeLog[i];
		if( Change->TransCount == UndoTransCount )
			ApplyChange (Change,Buffer + Transaction->StartDataOffset + Change->DataOffset,Change->DataSize);
	}
	EndChanges (Transaction);
	UndoTransCount++;
	Unlock(LOCK_ReadWrite);
	return 1;
	unguard;
}

/*-----------------------------------------------------------------------------
	Logging individual transactions.
-----------------------------------------------------------------------------*/

//
// Notce a single record added, deleted, or changed during a transaction.  Index
// is the index of the record in the object Res, or -1 to note changes to stuff
// in the object's header.
//
void UTransBuffer::NoteSingleChange( UObject *Res, int Index )
{
	guard(UTransBuffer::NoteSingleChange);

	UClass 			*Class 		 = Res->GetClass();
 	FTransaction	*Transaction = &Transactions [NumTrans-1];
	FTransChangeLog	*Changes;
	BYTE			*SourcePtr,*DestPtr;
	int				DataSize;

	if( !GApp->ServerAlive || !Res || !IsLocked() || Overflow )
		return;

	// There are more changes on file from past transactions than the system
	// can hold, so delete the first one.
	Transaction->NumChanges++;
	while( NumChanges>=MaxChanges && NumTrans>0 )
	{
		DeleteFirstTransaction();
		Transaction = &Transactions[NumTrans-1];
	}

	if( NumTrans == 0 )
	{
		Overflow:
		debugf("Transaction overflow");

		// This single transaction had more changes than the system can hold; end
		// transaction and mark it as "overflowed".
		if( NumChanges != 0 )
			appError ("NumChanges inconsistent");
		
		NumChanges = 0;
		Overflow   = 1;
		return;
	}

	// Add to change log.
	guard(1);
	Changes				= &ChangeLog[NumChanges++];
	Changes->TransCount	= TransCount - 1;
	Changes->Res		= Res;
	Changes->Index	 	= Index;
	Changes->DataOffset	= Transaction->TotalDataSize;
	unguardf(("%i/%i:%i/%i",NumChanges,MaxChanges,NumTrans-1,MaxTrans));

	if( Index >= 0 )
	{
		// Save a record of the object's data.
		DataSize  = Class->ResRecordSize;
		SourcePtr = ((BYTE *)Res->GetData()) + Index * Class->ResRecordSize;
		//debugf("Change %s.%s %i",Res->GetClassName(),Res->GetName(),Index);
	}
	else
	{
		// Save object header.
		DataSize  = Class->ResFullHeaderSize;
		SourcePtr = (BYTE *)Res;
		//debugf("Change %s.%s",Res->GetClassName(),Res->GetName());
	}
	Changes->DataSize = DataSize;

	// If there's not enough room in the data buffer, make room.
	guard(2);
	while( NumTrans>0 && (Transaction->StartDataOffset + Transaction->TotalDataSize + DataSize) > MaxDataOffset )
	{
		DeleteFirstTransaction();
		Transaction = &Transactions[NumTrans-1];
	}
	if( NumTrans == 0 )
		goto Overflow;
	unguardf(("%i/%i",NumChanges,MaxChanges));

	// Copy data.
	guard(3);
	DestPtr = Buffer + Transaction->StartDataOffset + Transaction->TotalDataSize;
	memcpy( DestPtr, SourcePtr, DataSize );
	unguard;

	// Update transaction's running data length.
	Transaction->TotalDataSize += DataSize;
	unguard;
}

/*-----------------------------------------------------------------------------
	Object header modification.
-----------------------------------------------------------------------------*/

//
// Object header.
//
void UTransBuffer::NoteResHeader( UObject *Res )
{
	guard(UTransBuffer::NoteResHeader);
	
	if( GApp->ServerAlive && Res )
		NoteSingleChange( Res, -1 );
	
	unguard;
}

/*-----------------------------------------------------------------------------
	UTransBuffer object implementation.
-----------------------------------------------------------------------------*/

void UTransBuffer::InitHeader()
{
	guard(UTransBuffer::InitHeader);

	// Call parent.
	UObject::InitHeader();

	// Init object header to defaults.
	Overflow		= 0;
	TransCount		= 0;
	UndoTransCount	= 0;
	NumTrans		= 0;
	MaxTrans		= 0;
	NumChanges		= 0;
	MaxChanges		= 0;
	MaxDataOffset	= 0;

	strcpy (ResetAction,"startu[");

	unguard;
}
int UTransBuffer::QuerySize()
{
	guard(UTransBuffer::QuerySize);

	DWORD TransactionSize  = MaxTrans 	* sizeof (FTransaction);
	DWORD ChangeLogSize    = MaxChanges * sizeof (FTransChangeLog);
	DWORD DataSize		   = MaxDataOffset;
	DWORD TotalSize		   = TransactionSize + ChangeLogSize + DataSize;
	return TotalSize;

	unguard;
}
int UTransBuffer::QueryMinSize()
{
	guard(UTransBuffer::QueryMinSize);
	return QuerySize();
	unguard;
}
void UTransBuffer::SerializeData(FArchive &Ar)
{
	guard(UTransBuffer::SerializeData);

	//Note: Since this object is not saveable, we only
	// need to serialize our object and name references.
	FTransChangeLog *Changes = (FTransChangeLog  *)((BYTE *)GetData() + MaxTrans * sizeof (FTransaction));
	for( int i=0; i<NumChanges; i++ )
	{
		if( Changes[i].Index == -1 )
			Ar << Changes[i].Res;
	}
	unguard;
}
IMPLEMENT_CLASS(UTransBuffer);

/*-----------------------------------------------------------------------------
	The End.
-----------------------------------------------------------------------------*/
