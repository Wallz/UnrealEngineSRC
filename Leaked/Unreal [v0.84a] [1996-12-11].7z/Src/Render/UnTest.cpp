/*=============================================================================
	UnCache.cpp: FMemoryCache implementation.

	Copyright 1996 Epic MegaGames, Inc. This software is a trade secret.
	Compiled with Visual C++ 4.0. Best viewed with Tabs=4.

	Revision history:
		* Initially implementated by Mark Randell.
		* Rewritten by Tim Sweeney (speed, speed, speed!)
=============================================================================*/
